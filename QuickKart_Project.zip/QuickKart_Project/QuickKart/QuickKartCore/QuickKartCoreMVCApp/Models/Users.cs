﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace QuickKartCoreMVCApp.Models
{
    public class Users
    {
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address.")]
        [Required(ErrorMessage = "EmailId is mandatory.")]
        [DisplayName("Email Id")]
        public string EmailId { get; set; }

        [Required(ErrorMessage = "Password is mandatory.")]
        [DisplayName("User password")]
        [StringLength(maximumLength: 10)]
        public string UserPassword { get; set; }

        [ScaffoldColumn(false)]
        public Nullable<byte> RoleId { get; set; }

        [RegularExpression("M|F", ErrorMessage = "Gender should be M or F")]
        [Required(ErrorMessage = "Gender is mandatory.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "DOB is mandatory.")]
        [DisplayName("Date of birth")]
        [DataType(DataType.Date)]
        public System.DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Address is mandatory.")]
        public string Address { get; set; }
    }
}
