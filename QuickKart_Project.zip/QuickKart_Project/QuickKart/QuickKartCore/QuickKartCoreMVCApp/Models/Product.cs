﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QuickKartCoreMVCApp.Models
{
    public class Product
    {
        [Required(ErrorMessage ="Category Id is mandatory")]
        [DisplayName("Category Id")]
        public byte? CategoryId { get; set; }

        
        [DisplayName("Price")]
        [Required(ErrorMessage = "Price is mandatory")]
        public decimal? Price { get; set; }

        [Required(ErrorMessage = "Product Id is mandatory")]
        [DisplayName("Product Id")]
        public string ProductId { get; set; }

        [Required(ErrorMessage = "Product Name is mandatory")]
        [DisplayName("Product Name")]
        [MinLength(3,ErrorMessage = "Product name should contain minimum three characters")]
        public string ProductName { get; set; }

        
        [DisplayName("Quantity Available")]
        [Required(ErrorMessage = "Quantity Available is mandatory")]
        [Range(0,int.MaxValue,ErrorMessage ="Quantity should be greater than zero.")]
        public int? QuantityAvailable { get; set; }
    }
}
