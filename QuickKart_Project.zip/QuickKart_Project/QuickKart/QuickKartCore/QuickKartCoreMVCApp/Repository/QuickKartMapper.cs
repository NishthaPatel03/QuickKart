﻿using AutoMapper;
using QuickKartDataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickKartCoreMVCApp.Repository
{
    public class QuickKartMapper : Profile
    {
        public QuickKartMapper()
        {
            CreateMap<Products, Models.Product>();
            CreateMap<Models.Product, Products>();

            CreateMap<Categories, Models.Categories>();
            CreateMap<Models.Categories, Categories>();

            CreateMap<Models.PurchaseDetails, PurchaseDetails>();
        }
    }
}
