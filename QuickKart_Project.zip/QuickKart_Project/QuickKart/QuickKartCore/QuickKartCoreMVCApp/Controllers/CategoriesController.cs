﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartCoreMVCApp.Controllers
{
    public class CategoriesController : Controller
    {

        private readonly QuickKartContext _context;
        QuickKartRepository repObj;
        private readonly IMapper _mapper;

        public CategoriesController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }


        public IActionResult AddCategory()
        {

            return View();
        }

        public IActionResult SaveCategory(Models.Categories category)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Categories categories = new Categories();
                    categories.CategoryId = category.CategoryId;
                    categories.CategoryName = category.CategoryName;
                    bool res = repObj.AddCategory(categories);
                    if (res)
                        return RedirectToAction("AdminHome", "Admin");
                    else
                        return View("Error");
                }
                catch (Exception e)
                {
                    Debug.Write(e.Message);
                }
            }
            return View("AddCategory");

            //bool status = false;
            //if (ModelState.IsValid)
            //{
            //    try
            //    {
            //        status = repObj.AddCategory(_mapper.Map<Categories>(category));
            //        if (status)
            //            return RedirectToAction("ViewCategory");
            //        else
            //            return View("Error");
            //    }
            //    catch (Exception)
            //    {
            //        return View("Error");
            //    }
            //}
            //return View("AddCategory", category);
        }

        public IActionResult UpdateCategory(Models.Categories category)
        {
            return View(category);
        }

        [HttpPost]
        public IActionResult SaveUpdatedCategory(Models.Categories category)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.UpdateCategory(_mapper.Map<Categories>(category));
                    if (status)
                        return RedirectToAction("ViewCategory");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("UpdateProduct", category);
        }


        public IActionResult DeleteCategory(Models.Categories category)
        {
            return View(category);
        }

        public IActionResult SaveDeletion(Models.Categories catObj)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteCategory(_mapper.Map<Categories>(catObj));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }
        }


        public IActionResult ViewCategory()
        {
            var lstEntityCategories = repObj.GetCategories();
            List<Models.Categories> lstModelCategories = new List<Models.Categories>();
            foreach (var category in lstEntityCategories)
            {
                lstModelCategories.Add(_mapper.Map<Models.Categories>(category));
            }

            return View(lstModelCategories);
        }
    }

}
