﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

namespace QuickKartCoreMVCApp.Controllers
{
    public class ProductController : Controller
    {
        private readonly QuickKartContext _context;
        QuickKartRepository repObj;
        private readonly IMapper _mapper;

        public ProductController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            repObj = new QuickKartRepository(_context);
            _mapper = mapper;
        }

        public IActionResult GetProductForCategory(byte? categoryId)
        {
            ViewBag.CategoryList = repObj.GetCategories();
            var productList = repObj.GetProducts();
            var products = new List<Models.Product>();
            foreach (var product in productList)
            {
                products.Add(_mapper.Map<Models.Product>(product));
            }
            var filteredProducts = products.Where(model => model.CategoryId == categoryId);
            return View(filteredProducts);
        }


        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AddProduct()
        {
            string productId = repObj.GetNextProductId();
            ViewBag.NextProductId = productId;
            return View();
        }

        [HttpPost]
        public IActionResult SaveProduct(Models.Product product)
        {
            //if (ModelState.IsValid)
            //{
            //    Products pobj = new Products();
            //    pobj.CategoryId=product.CategoryId;
            //    pobj.Price = (decimal)product.Price;
            //    pobj.ProductId = product.ProductId;
            //    pobj.ProductName = product.ProductName;
            //    pobj.QuantityAvailable = (int)product.QuantityAvailable;
            //    bool res=repObj.AddProduct(pobj);
            //    if (res)
            //        return RedirectToAction("AdminHome", "Admin");
            //    else
            //        return View("Error");
            //}
            //return View("AddProduct");


            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.AddProduct(_mapper.Map<Products>(product));
                    if (status)
                        return RedirectToAction("ViewProducts");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("AddProduct", product);
        }



        public IActionResult UpdateProduct(Models.Product product)
        {
            return View(product);
        }

        [HttpPost]
        public IActionResult SaveUpdatedProduct(Models.Product product)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.UpdateProduct(_mapper.Map<Products>(product));
                    if (status)
                        return RedirectToAction("ViewProducts");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("UpdateProduct", product);
        }

        
       

        public IActionResult DeleteProduct(Models.Product product)
        {
            return View(product);
        }

        [HttpPost]
        public IActionResult SaveDeletion(string productId)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteProduct(productId);
                if (status)
                    return RedirectToAction("ViewProducts");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        public IActionResult ViewProducts()
        {

            var lstEntityProducts = repObj.GetProducts();
            List<Models.Product> lstModelProducts = new List<Models.Product>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Product>(product));
            }
            return View(lstModelProducts);
        }

    }
}